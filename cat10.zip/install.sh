#!/bin/sh
set -eu

DEST=/data/rlight
SCRIPT_DIR=$(CDPATH= cd -P "$(dirname "$0")" 2>/dev/null && pwd)
[ -n "$SCRIPT_DIR" ] || { echo "Cannot determine package directory" >&2; exit 1; }
SRC=$SCRIPT_DIR
STAGE=""
# Running install.sh from /data/rlight is supported: stage package files before cleanup.
if [ "$SCRIPT_DIR" = "$DEST" ]; then
    STAGE=/tmp/rlight-package.$$
    rm -rf "$STAGE"
    mkdir -p "$STAGE"
    cp -a "$SCRIPT_DIR"/. "$STAGE"/
    SRC=$STAGE
fi

case "$(uname -m 2>/dev/null || echo unknown)" in
    aarch64|arm64) ;;
    *)
        echo "This package requires OpenWrt AArch64. Detected: $(uname -m 2>/dev/null || echo unknown)" >&2
        exit 1
        ;;
esac

[ -x /sbin/procd ] || echo "Warning: /sbin/procd not found; this installer expects standard OpenWrt procd."
[ -f /etc/rc.common ] || { echo "Missing /etc/rc.common; not a compatible OpenWrt installation." >&2; exit 1; }

echo "Installing RLight OpenWrt AArch64 to fixed path $DEST"

# Stop a previous service and remove only RLight-owned firewall state.
[ -x /etc/init.d/rlight ] && /etc/init.d/rlight stop >/dev/null 2>&1 || true
[ -x "$DEST/usr/sbin/rlight-fw4" ] && "$DEST/usr/sbin/rlight-fw4" stop >/dev/null 2>&1 || true
pkill -f "$DEST/bin/rlight" >/dev/null 2>&1 || true
pkill -f "$DEST/bin/xray" >/dev/null 2>&1 || true

BACKUP=/tmp/rlight-install-backup.$$
rm -rf "$BACKUP"
mkdir -p "$BACKUP"
[ -d "$DEST/data" ] && cp -a "$DEST/data" "$BACKUP/data" 2>/dev/null || true
[ -d "$DEST/conf" ] && cp -a "$DEST/conf" "$BACKUP/conf" 2>/dev/null || true
[ -f "$DEST/bin/xray" ] && cp -a "$DEST/bin/xray" "$BACKUP/xray" 2>/dev/null || true

mkdir -p "$DEST"
rm -rf "$DEST/web" "$DEST/usr" "$DEST/etc" "$DEST/autostart"
rm -f "$DEST/bin/rlight" "$DEST/bin/tun2sock" "$DEST/bin/tun2socks"
mkdir -p "$DEST/bin" "$DEST/data" "$DEST/conf" "$DEST/run" "$DEST/logs"

# Copy package files. The package intentionally contains no Xray binary.
cp -a "$SRC"/. "$DEST"/

# Restore user nodes/settings and the user's own Xray binary.
[ -d "$BACKUP/data" ] && cp -a "$BACKUP/data"/. "$DEST/data"/ 2>/dev/null || true
[ -d "$BACKUP/conf" ] && cp -a "$BACKUP/conf"/. "$DEST/conf"/ 2>/dev/null || true
[ -f "$BACKUP/xray" ] && cp -a "$BACKUP/xray" "$DEST/bin/xray" 2>/dev/null || true
rm -rf "$BACKUP"
[ -n "$STAGE" ] && rm -rf "$STAGE"

rm -rf "$DEST/autostart"
rm -f "$DEST/bin/tun2sock" "$DEST/bin/tun2socks" "$DEST/usr/sbin/rlight-xray-update" "$DEST/usr/sbin/rlight-autostart"
mkdir -p "$DEST/run" "$DEST/logs" "$DEST/data" "$DEST/conf" "$DEST/bin"

chmod 755 \
    "$DEST/bin/rlight" \
    "$DEST/usr/sbin/rlight-fw4" \
    "$DEST/usr/sbin/rlight-procd" \
    "$DEST/usr/sbin/rlightctl" \
    "$DEST/etc/init.d/rlight"
[ -f "$DEST/bin/xray" ] && chmod 755 "$DEST/bin/xray"

if [ ! -f "$DEST/data/settings.json" ]; then
    cat > "$DEST/data/settings.json" <<'JSON'
{
  "dns": "1.1.1.1",
  "timeSync": "pool.ntp.org",
  "vpnMode": "global",
  "engineMode": "redirect",
  "proxyRouter": 1,
  "proxyUdp": 1,
  "includeWifiPhy": 0,
  "autorun": 1,
  "reconnect": 1,
  "password": "radu"
}
JSON
else
    # Normalize settings from older tun2sock/vendor packages.
    sed -i 's/"engineMode"[[:space:]]*:[[:space:]]*"[^"]*"/"engineMode": "redirect"/g' "$DEST/data/settings.json" || true
    sed -i 's/"autorun"[[:space:]]*:[[:space:]]*[0-9][0-9]*/"autorun": 1/g' "$DEST/data/settings.json" || true
fi

# Install the init script into OpenWrt's real init directory; runtime files remain under /data/rlight.
cp -f "$DEST/etc/init.d/rlight" /etc/init.d/rlight
chmod 755 /etc/init.d/rlight
ln -sf "$DEST/usr/sbin/rlightctl" /usr/sbin/rlightctl
ln -sf "$DEST/usr/sbin/rlight-fw4" /usr/sbin/rlight-fw4

/etc/init.d/rlight enable
/etc/init.d/rlight restart

cat <<EOF2

RLight installation complete.
  Fixed root:       $DEST
  WebUI/backend:    managed by /etc/init.d/rlight (procd)
  Boot autostart:   enabled
  Engine:           TCP REDIRECT + UDP TPROXY only
  Xray expected at: $DEST/bin/xray

Next steps:
  1. Copy your AArch64 Xray binary to $DEST/bin/xray
  2. chmod 755 $DEST/bin/xray
  3. Import/select a VLESS node in WebUI
  4. Run: rlightctl restart
  5. Check: rlightctl doctor

WebUI: http://<router-lan-ip>:5000
Default password: radu
EOF2

if [ ! -x "$DEST/bin/xray" ]; then
    echo "Note: Xray was not bundled and is currently missing, as requested."
fi
if ! command -v iptables >/dev/null 2>&1; then
    echo "Warning: iptables is missing. Install OpenWrt iptables compatibility packages."
fi
if ! iptables -t mangle -j TPROXY --help >/dev/null 2>&1; then
    echo "Warning: UDP TPROXY target is unavailable. Suggested packages: ip-full kmod-ipt-tproxy iptables-mod-tproxy."
fi
